# Gold AI Analyzer — PWA

Mobile-first static PWA with M5/M15/M30 candlestick chart, EMA20/50, RSI14, MACD, ATR14, rolling 30-candle support/resistance, exploratory historical next-candle up frequency, source links for news, foreground alerts and deterministic synthetic demo.

## Deploy for free from a phone

1. Create a **private** GitHub repository, and upload all files including `icons/`.
2. For easiest static deployment, use Cloudflare Pages: connect GitHub repo, choose a static project, set build command to blank and output directory to `/` (or use direct upload if available). Alternatively GitHub Pages on public repos, but do not put API keys in source.
3. Open the HTTPS URL in Android Chrome > menu > Add to Home screen / Install app.
4. Start in Demo mode. For live data, obtain a Twelve Data API key and enter it in Settings. Turn Demo off. Confirm that the provider's plan supports XAU/USD, 5min, 15min and 30min and enough credits. Browser API requests may be blocked by provider CORS or account plan; in that case a server-side proxy is required.

## Security / limitations

- API key is stored in localStorage **on your device** for convenience. It is exposed to browser-side requests and should be treated as a public/limited key. Never paste it into GitHub source or share it. For stronger security use a backend proxy with server-side secrets.
- Demo prices are synthetic and NOT current market prices. Demo uses deterministic synthetic data for each timeframe.
- Historical up frequency is not a calibrated probability. It selects historical candles with matching EMA20-relative position and RSI ±12 and reports the fraction followed by a higher close. If fewer than 20 matches, no percentage is shown. It does not guarantee future direction and may be affected by nonstationarity.
- Live feed removes the most recent bar to avoid using an in-progress candle, potentially lagging one extra candle depending on API behavior. Timestamps are provider-local and displayed as approximate UTC parsing.
- Alerts work only while the page is open and notifications are permitted. iOS and Android background push notifications require a push service/server.
- Auto refresh only works while app remains active. Free static hosting cannot schedule reliable background updates. The News section links to authoritative sites rather than claiming to ingest or score news automatically.
- The app does not trade or connect to a brokerage account. Educational monitoring only.

## Run locally

From this directory: `python -m http.server 8080` then open `http://localhost:8080`. PWA installation requires HTTPS or localhost.
